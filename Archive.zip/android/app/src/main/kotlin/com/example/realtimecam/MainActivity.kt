package com.example.realtimecam

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
