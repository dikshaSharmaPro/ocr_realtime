//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<flutter_mobile_vision_2/FlutterMobileVisionPlugin.h>)
#import <flutter_mobile_vision_2/FlutterMobileVisionPlugin.h>
#else
@import flutter_mobile_vision_2;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [FlutterMobileVisionPlugin registerWithRegistrar:[registry registrarForPlugin:@"FlutterMobileVisionPlugin"]];
}

@end
