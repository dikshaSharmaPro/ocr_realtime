import 'dart:developer';

import 'package:csv/csv.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_mobile_vision_2/flutter_mobile_vision_2.dart';

class NewDoc extends StatefulWidget {
  final List<OcrText> words;

  const NewDoc({Key? key, required this.words}) : super(key: key);

  @override
  _NewDocState createState() => _NewDocState();
}

class _NewDocState extends State<NewDoc> {
  List<String> _csvData = [];
  List<String> finalWordss = [];

  // List<String> _searchList = [
  //   '"DOCA"',
  //   'banana',
  //   'cucumber'
  // ]; // Example list to match against
  List<String> _matches = [];
  List<String> newAbc = [];

  @override
  void initState() {
    super.initState();
    loadCsv();
    _convertWords();
  }

  void _convertWords() {
    // Map each word to a quoted version and convert to a list

    finalWordss = widget.words.map((ocrText) => '"${ocrText.value}"').toList();
    newAbc = finalWordss[0].split(' ');
    // newAbc = finalWordss.map((word) => '"$word"').toList();
  }

  Future<void> loadCsv() async {
    try {
      // Load the CSV file
      final data = await rootBundle.loadString('assets/products.csv');

      // Split the CSV data into lines
      List<String> lines = data.split('\n');

      // Remove any trailing empty lines
      lines.removeWhere((line) => line.trim().isEmpty);

      // Strip quotes from each line
      List<String> strippedLines = lines.map((line) {
        return line.replaceAll('"', '');
      }).toList();

      // Update the state with the stripped lines
      setState(() {
        _csvData = strippedLines;
      });

      // Check for matches
      findMatches();
    } catch (e) {
      print('Error loading or parsing CSV: $e');
    }
  }

  void findMatches() {
    List<String> matches = [];
    for (var word in newAbc) {
      if (_csvData.contains(word)) {
        matches.add(word);
      }
    }
    setState(() {
      _matches = matches;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // log(newAbc[2]);
        },
      ),
      appBar: AppBar(
        title: Text('CSV Matcher'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'CSV Data:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: _csvData.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(_csvData[index]),
                  );
                },
              ),
            ),
            SizedBox(height: 10),
            Text(
              'Search List:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: newAbc.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(newAbc[index]),
                  );
                },
              ),
            ),
            SizedBox(height: 10),
            Text(
              'Matches Found from the CSV file and scanned text:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: _matches.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(
                      _matches[index],
                      style: TextStyle(
                          color: Colors.green, fontWeight: FontWeight.bold),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
